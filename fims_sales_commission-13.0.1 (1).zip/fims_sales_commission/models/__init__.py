# -*- coding: utf-8 -*-
###############################################################################
#
#    Fortutech IMS Pvt. Ltd.
#    Copyright (C) 2016-TODAY Fortutech IMS Pvt. Ltd.(<http://www.fortutechims.com>).
#
###############################################################################
from . import sale_order
from . import account_invoice
from . import res_partner
from . import sales_commission
from . import commission_line
from . import res_config_settings
